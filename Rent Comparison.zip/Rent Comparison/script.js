const currentCity = "Rio De Janeiro";
const compCity = "Medellin";
const currentRent = 1100;
const compRent = 650;
const isMoreExpensive = currentRent > compRent;
const comparisonLabel = currentCity + " is more expensive: " + isMoreExpensive;
const difference = currentRent - compRent;
const differenceLabel = "Rent difference: USD $" + difference;
document.getElementById("city1").innerHTML = currentCity + ": In US Dollars " +
  currentRent;
document.getElementById("city2").innerHTML = compCity + ": In US Dollars " + compRent;
document.getElementById("comparison").innerHTML = comparisonLabel;
document.getElementById("difference").innerHTML = differenceLabel;
console.log(comparisonLabel);
console.log(differenceLabel);